package com.stu.action;

import java.util.List;

import com.opensymphony.xwork2.ActionSupport;
import com.stu.entity.Stu;
import com.stu.service.StuService;

public class StuAction extends ActionSupport {

	private Stu s;
	private StuService ss=new StuService() ;
	
	private List<Stu>  stuList;

	public Stu getS() {
		return s;
	}

	public void setS(Stu s) {
		this.s = s;
	}

	public List<Stu> getStuList() {
		return stuList;
	}

	public void setStuList(List<Stu> stuList) {
		this.stuList = stuList;
	}

	
	
	public String execute() throws Exception {
		stuList=ss.findAll();
		return SUCCESS;
	}
}
