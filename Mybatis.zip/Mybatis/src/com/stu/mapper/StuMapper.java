package com.stu.mapper;

import java.util.List;

public interface StuMapper<T> {

	
	public List<T> findAll();
	public T findById(T t);
	public void insert (T t);
	public void delete (T t);
	public void update (T t);
}
