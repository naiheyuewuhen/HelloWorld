package com.stu.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.stu.entity.Stu;
import com.stu.mapper.StuMapper;
import com.stu.util.MyBatisUtil;

public class StuService {
private SqlSession session;
	public StuService() {
		session=MyBatisUtil.getFactory().openSession();
	}
	
	
	public List<Stu> findAll(){
		List<Stu> list=new ArrayList<Stu>();
		try {
			StuMapper sm=session.getMapper(StuMapper.class);
			list = sm.findAll();
			session.commit();
		} catch (Exception e) {
			session.rollback();
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			session.close();
		}
		return list;
		
	}
	
	public Stu findById(Stu s){
		List<Stu> list=new ArrayList<Stu>();
		try {
			StuMapper sm=session.getMapper(StuMapper.class);
			s = (Stu)sm.findById(s.getSid());
			session.commit();
		} catch (Exception e) {
			session.rollback();
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			session.close();
		}
		return s;
		
	}
	
	
	public void update(Stu s){
		
		try {
			StuMapper sm=session.getMapper(StuMapper.class);
			sm.update(s);
			session.commit();
		} catch (Exception e) {
			session.rollback();
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			session.close();
		}
	}
		public void delete(Stu s){
			
			try {
				StuMapper sm=session.getMapper(StuMapper.class);
				sm.delete(s.getSid());
				session.commit();
			} catch (Exception e) {
				session.rollback();
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				session.close();
			}
		
	}
public void insert(Stu s){
			
			try {
				StuMapper sm=session.getMapper(StuMapper.class);
				sm.insert(s);
				session.commit();
			} catch (Exception e) {
				session.rollback();
				// TODO Auto-generated catch block
				e.printStackTrace();
			}finally{
				session.close();
			}
		
	}
	
	
}
