package com.stu.util;

import java.io.InputStream;

import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class MyBatisUtil {
	private static SqlSessionFactory factory;
	
	static{
		InputStream in = MyBatisUtil.class.getResourceAsStream("/MyBatisConfiguration.xml");
		factory = new  SqlSessionFactoryBuilder().build(in);
	}
	
	public static SqlSessionFactory getFactory(){
		return factory;
	}
	
	

}
