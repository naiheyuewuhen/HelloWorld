package com.stu.entity;

import java.io.Serializable;

public class Stu implements Serializable {
private int sid;
private String sname;
private int age;
private String sex;
private String address;
public int getSid() {
	return sid;
}
public void setSid(int sid) {
	this.sid = sid;
}
public String getSname() {
	return sname;
}
public void setSname(String sname) {
	this.sname = sname;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public String getSex() {
	return sex;
}
public void setSex(String sex) {
	this.sex = sex;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
@Override
public String toString() {
	return "Stu [sid=" + sid + ", sname=" + sname + ", age=" + age + ", sex="
			+ sex + ", address=" + address + "]";
}


}
