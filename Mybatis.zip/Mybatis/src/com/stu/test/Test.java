package com.stu.test;

import java.util.Iterator;
import java.util.List;

import com.stu.entity.Stu;
import com.stu.service.StuService;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		StuService ss=new StuService();

		List<Stu> list=ss.findAll();
		Iterator<Stu> it=list.iterator();
		while(it.hasNext()){
			Stu s=it.next();
			System.out.println(s);
		}
	}

}
